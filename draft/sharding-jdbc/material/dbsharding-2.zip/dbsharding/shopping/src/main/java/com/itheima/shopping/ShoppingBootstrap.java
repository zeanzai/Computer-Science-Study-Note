package com.itheima.shopping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoppingBootstrap {

    public static void main(String[] args) {
        SpringApplication.run(ShoppingBootstrap.class, args);
    }

}
